import { createFileRoute } from "@tanstack/react-router";
import radioLogo from "@/assets/radio-logo.jpg.asset.json";
import radioBg from "@/assets/radio-bg.jpg.asset.json";
import { Play, Pause, Volume2, Mic, Timer, Music, Share2, MoreVertical, Instagram, Facebook, Globe, Youtube, Monitor, Radio, MessageCircle } from "lucide-react";
import { BsWhatsapp, BsChatLeftText, BsYoutube } from "react-icons/bs";
import { useState, useRef, useEffect } from "react";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    title: "Rádio Cidade Jardim Web - A rádio que toca você",
    meta: [
      { name: "description", content: "Ouça a Rádio Cidade Jardim Web ao vivo. A melhor programação musical e notícias da região." },
      { property: "og:title", content: "Rádio Cidade Jardim Web" },
      { property: "og:description", content: "Ouça ao vivo a Rádio Cidade Jardim Web." },
      { property: "og:image", content: radioLogo.url },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function Index() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(67);
  const [isStationsOpen, setIsStationsOpen] = useState(false);
  const [currentStation, setCurrentStation] = useState({
    name: "Cidade Jardim Web",
    url: "http://stm12.srvvox.com.br:7186/stream?1786342496847"
  });
  const audioRef = useRef<HTMLAudioElement>(null);

  const stations = [
    { name: "Cidade Jardim Web", url: "http://stm12.srvvox.com.br:7186/stream?1786342496847" },
    { name: "Metropolitana FM", url: "https://ice-br.fabricahost.com.br/play/metropolitana985sp?1786746441399" },
    { name: "Radio Bandeirantes FM", url: "https://playerservices.streamtheworld.com/api/livestream-redirect/RadioBandeirantesAAC.aac?dist=RADIOSNET&1786746530439" },
    { name: "Radio CBN", url: "https://27583.live.streamtheworld.com/CBN_SPAAC.aac?dist=radioscombr&1786746602686" },
    { name: "Forró das Antigas", url: "http://stm17.srvvox.com.br:7350/stream?1786746083763" },
    { name: "Antena 1", url: "https://antenaone.crossradio.com.br/stream/1;?1786746323257" },
    { name: "Rádio Sertaneja", url: "https://stream.zeno.fm/f9u3wz7t1h0uv" },
    { name: "Top Hits Brasil", url: "https://stream.zeno.fm/s4yv4p4h2a0uv" },
    { name: "Rádio Gospel", url: "https://stream.zeno.fm/u2v4yq2h2a0uv" },
  ];

  const handleStationChange = (station: { name: string, url: string }) => {
    setCurrentStation(station);
    setIsPlaying(false);
    if (audioRef.current) {
      audioRef.current.load();
      setTimeout(() => {
        audioRef.current?.play();
        setIsPlaying(true);
      }, 100);
    }
    setIsStationsOpen(false);
  };

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume / 100;
    }
  }, [volume]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play().catch(err => console.error("Erro ao reproduzir áudio:", err));
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="min-h-screen bg-[#05050a] text-white font-sans overflow-x-hidden">
      {/* Top Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between p-4 bg-gradient-to-b from-black/80 to-transparent">
        <h1 className="text-xl font-semibold">Rádio Cidade Jardim Web</h1>
        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-white/10 rounded-full transition-colors"><Share2 size={24} /></button>
          <button className="p-2 hover:bg-white/10 rounded-full transition-colors"><MoreVertical size={24} /></button>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative min-h-screen pt-16 pb-32 flex flex-col items-center">
        {/* Background with Overlay */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[#0a0f2b]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.15)_0%,transparent_70%)]" />
        </div>

        {/* Radio Brand Section */}
        <div className="relative z-10 flex flex-col items-center mt-12 mb-8">
          <div className="relative">
             <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 bg-black text-white text-[10px] font-bold px-2 py-0.5 rounded border border-white/20 tracking-tighter uppercase">
              {isPlaying ? "AO VIVO" : "PAUSADO"}
            </div>
            <div className="w-48 h-48 md:w-56 md:h-56 rounded-full overflow-hidden border-4 border-white/10 shadow-2xl">
              <img src={radioLogo.url} alt="Logo" className="w-full h-full object-cover" />
            </div>
          </div>
          <h2 className="text-2xl font-bold mt-6">{currentStation.name}</h2>
          <div className="flex gap-1 mt-2">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="w-4 h-1 bg-white/20 rounded-full" />
            ))}
          </div>
          <button 
            onClick={() => console.log("Download App button clicked")}
            className="mt-8 px-6 py-3 bg-blue-600 rounded-full text-lg font-bold hover:bg-blue-700 transition-colors shadow-lg">
            Baixar o Aplicativo
          </button>
        </div>

        {/* Social Links */}
        <div className="relative z-10 flex gap-4 mb-12">
          <button className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition-colors">
            <Globe size={20} />
          </button>
          <button className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition-colors">
            <Monitor size={20} />
          </button>
          <button className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition-colors">
            <Instagram size={20} />
          </button>
          <button className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition-colors">
            <Facebook size={20} />
          </button>
          <button className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition-colors">
            <Youtube size={20} />
          </button>
          <button className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10 transition-colors">
            <MessageCircle size={20} />
          </button>
        </div>

        {/* Partners/Ads Section */}
        <div className="relative z-10 w-full px-4 mb-8">
          <p className="text-center text-[10px] font-bold text-white uppercase tracking-[0.2em] mb-4">COLABORADORES</p>
          <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar justify-center">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex-shrink-0 w-44 h-28 bg-black rounded-3xl flex flex-col items-center justify-center p-4 border-b-2 border-white/10 shadow-xl">
                <p className="text-[10px] font-medium text-white/60 uppercase">COLABORADOR</p>
                <p className="text-sm font-bold uppercase text-center mt-1 leading-tight">ANUNCIE AQUI<br/>(88) 9999-9999</p>
                <p className="text-[9px] text-white/40 mt-2">Entre em contato e saiba mais</p>
              </div>
            ))}
          </div>
          <div className="flex justify-center gap-1.5 mt-2">
            <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
            {[...Array(4)].map((_, i) => (
              <div key={i} className="w-1.5 h-1.5 bg-white/20 rounded-full" />
            ))}
          </div>
        </div>

        {/* Control Panel */}
        <div className="fixed bottom-0 left-0 right-0 z-50 p-6 bg-[#0a0a14]/95 backdrop-blur-2xl border-t border-white/5 rounded-t-[3rem] shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
          <div className="max-w-xl mx-auto">
            {/* Top Row Controls */}
            <div className="flex items-center justify-between px-2 mb-8">
              <button className="flex flex-col items-center gap-1.5 group">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white/80 group-hover:bg-white/10 transition-colors">
                  <Timer size={22} />
                </div>
                <span className="text-[10px] font-bold text-white/60 tracking-wider">Timer</span>
              </button>

              <button 
                onClick={() => setIsStationsOpen(true)}
                className="flex flex-col items-center gap-1.5 group"
              >
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white/80 group-hover:bg-white/10 transition-colors">
                  <Radio size={22} />
                </div>
                <span className="text-[10px] font-bold text-white/60 tracking-wider">Estações</span>
              </button>

              <button className="flex flex-col items-center gap-1.5 group">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white/80 group-hover:bg-white/10 transition-colors">
                  <Monitor size={22} />
                </div>
                <span className="text-[10px] font-bold text-white/60 tracking-wider">TV Ao Vivo</span>
              </button>

              <button 
                onClick={togglePlay}
                className="w-20 h-20 bg-cyan-400 text-black rounded-full flex items-center justify-center hover:scale-105 transition-all shadow-[0_0_30px_rgba(34,211,238,0.4)] active:scale-95"
              >
                {isPlaying ? <Pause size={36} fill="black" /> : <Play size={36} fill="black" className="ml-1" />}
              </button>

              <button className="flex flex-col items-center gap-1.5 group">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white/80 group-hover:bg-white/10 transition-colors">
                  <Share2 size={22} />
                </div>
                <span className="text-[10px] font-bold text-white/60 tracking-wider">Compartilhar</span>
              </button>

              <div className="flex flex-col items-center gap-1.5">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white/80">
                  <Volume2 size={22} />
                </div>
                <span className="text-[10px] font-bold text-white/60 tracking-wider">{volume}%</span>
              </div>
            </div>

            {/* Volume Slider */}
            <div className="flex items-center gap-4 px-2 pb-2">
              <button onClick={() => setVolume(0)}>
                <Volume2 size={16} className="text-white/40 hover:text-white transition-colors" />
              </button>
              <div className="relative flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div 
                  className="absolute top-0 left-0 h-full bg-cyan-400" 
                  style={{ width: `${volume}%` }}
                />
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  value={volume}
                  onChange={(e) => setVolume(parseInt(e.target.value))}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>
              <Volume2 size={16} className="text-white/40" />
            </div>
          </div>
        </div>
      </div>

      <audio 
        ref={audioRef}
        src={currentStation.url} 
        className="hidden"
        crossOrigin="anonymous"
      />

      {/* Stations Modal */}
      {isStationsOpen && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#12121e] rounded-[2rem] overflow-hidden border border-white/10 shadow-2xl animate-in fade-in slide-in-from-bottom-8">
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <Radio className="text-cyan-400" /> Estações
              </h3>
              <button 
                onClick={() => setIsStationsOpen(false)}
                className="p-2 hover:bg-white/5 rounded-full transition-colors"
              >
                <MoreVertical size={20} className="rotate-45" />
              </button>
            </div>
            <div className="max-h-[60vh] overflow-y-auto p-4 space-y-2">
              {stations.map((station) => (
                <button
                  key={station.name}
                  onClick={() => handleStationChange(station)}
                  className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all ${
                    currentStation.name === station.name 
                      ? "bg-cyan-400/20 border border-cyan-400/50" 
                      : "bg-white/5 border border-transparent hover:bg-white/10"
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      currentStation.name === station.name ? "bg-cyan-400 text-black" : "bg-white/10 text-white"
                    }`}>
                      <Music size={20} />
                    </div>
                    <div className="text-left">
                      <p className="font-bold">{station.name}</p>
                      <p className="text-[10px] text-white/40 uppercase">Rádio Online</p>
                    </div>
                  </div>
                  {currentStation.name === station.name && (
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                  )}
                </button>
              ))}
            </div>
            <div className="p-4 bg-white/5 text-center">
              <p className="text-[10px] text-white/30 uppercase tracking-[0.2em]">Inspirado no RadiosNet</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
